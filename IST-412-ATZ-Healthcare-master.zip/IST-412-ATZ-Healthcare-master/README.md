# IST-412-ATZ-Healthcare
Group project for IST 412. Creating a Java FXML application for a healthcare company to manage patient data
